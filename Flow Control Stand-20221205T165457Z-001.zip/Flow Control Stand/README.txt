Files in this folder
===========================
Flow Control Stand F360.f3d
	-Autodesk Fusion 360 Archive Files
Flow Control Stand STEP.step
	-STEP Files
Stand Bottom Left.stl
Stand Bottom Right.stl
Stand Top Left.stl
Stand Top Right.stl
	-STL Files

About
======
Because of the size of the flow control stand the stand is divided into 4 STL files for easier 3D printing. Other file formats are included if needed for editing purposes. After printing, the parts should fit together with little to no adjustments. Issues with 3D printing may require you to sand the connecting faces to get a proper fit.

Print Settings
=====================
Print Material: PLA
Layer Height: 0.2mm
Wall Thickness: 1.6mm
Infill Density: 20%
Printing Temperature: 230°C
Build Plate Temperature: 70°C
Build Plate Adhesion Type: Skirt
Supports: none

Time and Material
==================
Approximate time and material when printed with the above settings

Part              | Time  | Filament
---------------------------------------
Stand Bottom Left | 7:45h | 70g
Stand Bottom Right| 8:00h | 72g
Stand Top Left	  | 2:45h | 27g
Stand Top Right	  | 4:30h | 46g